from base_datos.conexion10 import BaseDatos
from crud_producto.producto import Productos  # Especifica el archivo de donde proviene Producto

def main():
    # Tu código principal aquí
    pass

if __name__ == "__main__":
    main()