import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from crud_citas.citas import Citas
from crud_citas.menucit import MenuCitas
MenuCitas.menu_citas()